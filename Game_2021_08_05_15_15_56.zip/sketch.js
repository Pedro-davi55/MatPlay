function setup() {
  createCanvas(700, 500);
}

function draw() {
  background("#D22626");
}